﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BTWinForm
{
    public partial class frm_ThongtinSV : Form
    {
        public frm_ThongtinSV()
        {
            InitializeComponent();
            btnXoa.Enabled = false; // Disable nút xóa khi khởi tạo
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu nhập
            if (string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string[] row = {
                txtLastName.Text.Trim(),
                txtFirstName.Text.Trim(),
                txtPhone.Text.Trim()
            };

            ListViewItem item = new ListViewItem(row);

            // Thêm vào ListView
            lvDSSV.Items.Add(item);

            // Xóa nội dung textbox sau khi thêm
            txtLastName.Text = "";
            txtFirstName.Text = "";
            txtPhone.Text = "";

            // Focus vào ô nhập đầu tiên
            txtLastName.Focus();
        }

        private void frm_ThongtinSV_Load(object sender, EventArgs e)
        {
            lvDSSV.View = View.Details;
            lvDSSV.FullRowSelect = true;
            lvDSSV.GridLines = true;
            lvDSSV.OwnerDraw = true; // Bật chế độ tự vẽ

            // Thêm các cột
            if (lvDSSV.Columns.Count == 0)
            {
                lvDSSV.Columns.Add("Last Name", 100);
                lvDSSV.Columns.Add("First Name", 120);
                lvDSSV.Columns.Add("Phone", 100);
            }

            // Đăng ký sự kiện DrawColumnHeader
            lvDSSV.DrawColumnHeader += lvDSSV_DrawColumnHeader;
            lvDSSV.DrawItem += lvDSSV_DrawItem;
            lvDSSV.DrawSubItem += lvDSSV_DrawSubItem;
        }

        private void lvDSSV_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            // Tạo font bold cỡ 12
            Font headerFont = new Font("Microsoft Sans Serif", 12, FontStyle.Bold);

            // Vẽ nền tiêu đề cột
            e.Graphics.FillRectangle(Brushes.LightGray, e.Bounds);

            // Vẽ chữ căn giữa
            StringFormat format = new StringFormat();
            format.Alignment = StringAlignment.Center;
            format.LineAlignment = StringAlignment.Center;

            e.Graphics.DrawString(e.Header.Text, headerFont, Brushes.Black, e.Bounds, format);

            // Vẽ đường viền
            e.Graphics.DrawRectangle(Pens.Gray, e.Bounds);
        }

        private void lvDSSV_DrawItem(object sender, DrawListViewItemEventArgs e)
        {
            e.DrawDefault = true; // Vẽ mặc định cho items
        }

        private void lvDSSV_DrawSubItem(object sender, DrawListViewSubItemEventArgs e)
        {
            e.DrawDefault = true;
        }

        private void lvDSSV_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            btnXoa.Enabled = (lvDSSV.SelectedItems.Count > 0);
            // Kiểm tra có item nào được chọn không
            if (lvDSSV.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = lvDSSV.SelectedItems[0];

                // Hiển thị dữ liệu từ ListView lên các textbox
                txtLastName.Text = selectedItem.SubItems[0].Text;    // Cột 1: Last Name
                txtFirstName.Text = selectedItem.SubItems[1].Text;   // Cột 2: First Name  
                txtPhone.Text = selectedItem.SubItems[2].Text;       // Cột 3: Phone
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // Kiểm tra có item nào được chọn không
            if (lvDSSV.SelectedItems.Count > 0)
            {
                // Hiển thị hộp thoại xác nhận
                DialogResult result = MessageBox.Show(
                    "Bạn có chắc chắn muốn xóa sinh viên này?",
                    "Xác nhận xóa",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Xóa item được chọn
                    lvDSSV.SelectedItems[0].Remove();

                    // Xóa nội dung textbox sau khi xóa
                    txtLastName.Text = "";
                    txtFirstName.Text = "";
                    txtPhone.Text = "";
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sinh viên cần xóa!", "Thông báo",
                              MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
